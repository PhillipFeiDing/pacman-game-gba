/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_wall_o image_wall_o.png 
 * Time-stamp: Sunday 11/03/2019, 06:35:54
 * 
 * Image Information
 * -----------------
 * image_wall_o.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_WALL_O_H
#define IMAGE_WALL_O_H

extern const unsigned short image_wall_o[64];
#define IMAGE_WALL_O_SIZE 128
#define IMAGE_WALL_O_LENGTH 64
#define IMAGE_WALL_O_WIDTH 8
#define IMAGE_WALL_O_HEIGHT 8

#endif

