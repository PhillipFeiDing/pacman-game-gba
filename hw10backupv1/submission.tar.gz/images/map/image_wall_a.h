/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_wall_a image_wall_a.png 
 * Time-stamp: Sunday 11/03/2019, 06:34:41
 * 
 * Image Information
 * -----------------
 * image_wall_a.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_WALL_A_H
#define IMAGE_WALL_A_H

extern const unsigned short image_wall_a[64];
#define IMAGE_WALL_A_SIZE 128
#define IMAGE_WALL_A_LENGTH 64
#define IMAGE_WALL_A_WIDTH 8
#define IMAGE_WALL_A_HEIGHT 8

#endif

