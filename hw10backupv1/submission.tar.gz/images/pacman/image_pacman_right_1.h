/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=14x14 image_pacman_right_1 image_pacman_right_1.png 
 * Time-stamp: Sunday 11/03/2019, 06:25:00
 * 
 * Image Information
 * -----------------
 * image_pacman_right_1.png 14@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_PACMAN_RIGHT_1_H
#define IMAGE_PACMAN_RIGHT_1_H

extern const unsigned short image_pacman_right_1[196];
#define IMAGE_PACMAN_RIGHT_1_SIZE 392
#define IMAGE_PACMAN_RIGHT_1_LENGTH 196
#define IMAGE_PACMAN_RIGHT_1_WIDTH 14
#define IMAGE_PACMAN_RIGHT_1_HEIGHT 14

#endif

