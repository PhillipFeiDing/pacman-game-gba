/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 image_gameover image_gameover.png 
 * Time-stamp: Sunday 11/03/2019, 06:42:10
 * 
 * Image Information
 * -----------------
 * image_gameover.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_GAMEOVER_H
#define IMAGE_GAMEOVER_H

extern const unsigned short image_gameover[38400];
#define IMAGE_GAMEOVER_SIZE 76800
#define IMAGE_GAMEOVER_LENGTH 38400
#define IMAGE_GAMEOVER_WIDTH 240
#define IMAGE_GAMEOVER_HEIGHT 160

#endif

