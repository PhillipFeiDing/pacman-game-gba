/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=14x14 image_dead_ghost_right image_dead_ghost_right.png 
 * Time-stamp: Saturday 11/16/2019, 04:37:09
 * 
 * Image Information
 * -----------------
 * image_dead_ghost_right.png 14@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_DEAD_GHOST_RIGHT_H
#define IMAGE_DEAD_GHOST_RIGHT_H

extern const unsigned short image_dead_ghost_right[196];
#define IMAGE_DEAD_GHOST_RIGHT_SIZE 392
#define IMAGE_DEAD_GHOST_RIGHT_LENGTH 196
#define IMAGE_DEAD_GHOST_RIGHT_WIDTH 14
#define IMAGE_DEAD_GHOST_RIGHT_HEIGHT 14

#endif

