/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=14x14 image_red_ghost_down_0 image_red_ghost_down_0.png 
 * Time-stamp: Friday 11/15/2019, 21:19:00
 * 
 * Image Information
 * -----------------
 * image_red_ghost_down_0.png 14@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_RED_GHOST_DOWN_0_H
#define IMAGE_RED_GHOST_DOWN_0_H

extern const unsigned short image_red_ghost_down_0[196];
#define IMAGE_RED_GHOST_DOWN_0_SIZE 392
#define IMAGE_RED_GHOST_DOWN_0_LENGTH 196
#define IMAGE_RED_GHOST_DOWN_0_WIDTH 14
#define IMAGE_RED_GHOST_DOWN_0_HEIGHT 14

#endif

