/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=14x14 image_dead_ghost_up image_dead_ghost_up.png 
 * Time-stamp: Saturday 11/16/2019, 04:37:17
 * 
 * Image Information
 * -----------------
 * image_dead_ghost_up.png 14@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_DEAD_GHOST_UP_H
#define IMAGE_DEAD_GHOST_UP_H

extern const unsigned short image_dead_ghost_up[196];
#define IMAGE_DEAD_GHOST_UP_SIZE 392
#define IMAGE_DEAD_GHOST_UP_LENGTH 196
#define IMAGE_DEAD_GHOST_UP_WIDTH 14
#define IMAGE_DEAD_GHOST_UP_HEIGHT 14

#endif

