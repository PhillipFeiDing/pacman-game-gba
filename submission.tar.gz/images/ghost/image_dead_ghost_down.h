/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=14x14 image_dead_ghost_down image_dead_ghost_down.png 
 * Time-stamp: Saturday 11/16/2019, 04:37:23
 * 
 * Image Information
 * -----------------
 * image_dead_ghost_down.png 14@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_DEAD_GHOST_DOWN_H
#define IMAGE_DEAD_GHOST_DOWN_H

extern const unsigned short image_dead_ghost_down[196];
#define IMAGE_DEAD_GHOST_DOWN_SIZE 392
#define IMAGE_DEAD_GHOST_DOWN_LENGTH 196
#define IMAGE_DEAD_GHOST_DOWN_WIDTH 14
#define IMAGE_DEAD_GHOST_DOWN_HEIGHT 14

#endif

