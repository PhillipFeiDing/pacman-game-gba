/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=14x14 image_blue_ghost_down_1 image_blue_ghost_down_1.png 
 * Time-stamp: Friday 11/15/2019, 21:55:32
 * 
 * Image Information
 * -----------------
 * image_blue_ghost_down_1.png 14@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_BLUE_GHOST_DOWN_1_H
#define IMAGE_BLUE_GHOST_DOWN_1_H

extern const unsigned short image_blue_ghost_down_1[196];
#define IMAGE_BLUE_GHOST_DOWN_1_SIZE 392
#define IMAGE_BLUE_GHOST_DOWN_1_LENGTH 196
#define IMAGE_BLUE_GHOST_DOWN_1_WIDTH 14
#define IMAGE_BLUE_GHOST_DOWN_1_HEIGHT 14

#endif

