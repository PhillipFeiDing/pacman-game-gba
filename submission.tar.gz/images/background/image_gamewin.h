/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 image_gamewin image_gamewin.png 
 * Time-stamp: Tuesday 11/05/2019, 03:21:41
 * 
 * Image Information
 * -----------------
 * image_gamewin.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_GAMEWIN_H
#define IMAGE_GAMEWIN_H

extern const unsigned short image_gamewin[38400];
#define IMAGE_GAMEWIN_SIZE 76800
#define IMAGE_GAMEWIN_LENGTH 38400
#define IMAGE_GAMEWIN_WIDTH 240
#define IMAGE_GAMEWIN_HEIGHT 160

#endif

