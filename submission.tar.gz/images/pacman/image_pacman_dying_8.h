/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 image_pacman_dying_8 image_pacman_dying_8.png 
 * Time-stamp: Sunday 11/17/2019, 03:12:41
 * 
 * Image Information
 * -----------------
 * image_pacman_dying_8.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_PACMAN_DYING_8_H
#define IMAGE_PACMAN_DYING_8_H

extern const unsigned short image_pacman_dying_8[225];
#define IMAGE_PACMAN_DYING_8_SIZE 450
#define IMAGE_PACMAN_DYING_8_LENGTH 225
#define IMAGE_PACMAN_DYING_8_WIDTH 15
#define IMAGE_PACMAN_DYING_8_HEIGHT 15

#endif

