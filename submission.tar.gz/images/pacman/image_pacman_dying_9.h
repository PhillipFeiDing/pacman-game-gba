/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 image_pacman_dying_9 image_pacman_dying_9.png 
 * Time-stamp: Sunday 11/17/2019, 03:12:48
 * 
 * Image Information
 * -----------------
 * image_pacman_dying_9.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_PACMAN_DYING_9_H
#define IMAGE_PACMAN_DYING_9_H

extern const unsigned short image_pacman_dying_9[225];
#define IMAGE_PACMAN_DYING_9_SIZE 450
#define IMAGE_PACMAN_DYING_9_LENGTH 225
#define IMAGE_PACMAN_DYING_9_WIDTH 15
#define IMAGE_PACMAN_DYING_9_HEIGHT 15

#endif

