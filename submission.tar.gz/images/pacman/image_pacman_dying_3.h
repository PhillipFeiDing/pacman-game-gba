/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 image_pacman_dying_3 image_pacman_dying_3.png 
 * Time-stamp: Sunday 11/17/2019, 03:12:13
 * 
 * Image Information
 * -----------------
 * image_pacman_dying_3.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_PACMAN_DYING_3_H
#define IMAGE_PACMAN_DYING_3_H

extern const unsigned short image_pacman_dying_3[225];
#define IMAGE_PACMAN_DYING_3_SIZE 450
#define IMAGE_PACMAN_DYING_3_LENGTH 225
#define IMAGE_PACMAN_DYING_3_WIDTH 15
#define IMAGE_PACMAN_DYING_3_HEIGHT 15

#endif

