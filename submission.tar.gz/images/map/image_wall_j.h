/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_wall_j image_wall_j.png 
 * Time-stamp: Sunday 11/03/2019, 06:35:26
 * 
 * Image Information
 * -----------------
 * image_wall_j.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_WALL_J_H
#define IMAGE_WALL_J_H

extern const unsigned short image_wall_j[64];
#define IMAGE_WALL_J_SIZE 128
#define IMAGE_WALL_J_LENGTH 64
#define IMAGE_WALL_J_WIDTH 8
#define IMAGE_WALL_J_HEIGHT 8

#endif

