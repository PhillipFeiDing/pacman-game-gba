/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=2x2 image_food_tiny image_food_tiny.png 
 * Time-stamp: Saturday 11/16/2019, 07:22:18
 * 
 * Image Information
 * -----------------
 * image_food_tiny.png 2@2
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_FOOD_TINY_H
#define IMAGE_FOOD_TINY_H

extern const unsigned short image_food_tiny[4];
#define IMAGE_FOOD_TINY_SIZE 8
#define IMAGE_FOOD_TINY_LENGTH 4
#define IMAGE_FOOD_TINY_WIDTH 2
#define IMAGE_FOOD_TINY_HEIGHT 2

#endif

