/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_big_food image_big_food.png 
 * Time-stamp: Saturday 11/16/2019, 03:31:55
 * 
 * Image Information
 * -----------------
 * image_big_food.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_BIG_FOOD_H
#define IMAGE_BIG_FOOD_H

extern const unsigned short image_big_food[64];
#define IMAGE_BIG_FOOD_SIZE 128
#define IMAGE_BIG_FOOD_LENGTH 64
#define IMAGE_BIG_FOOD_WIDTH 8
#define IMAGE_BIG_FOOD_HEIGHT 8

#endif

