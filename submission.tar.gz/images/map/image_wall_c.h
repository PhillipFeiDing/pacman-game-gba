/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_wall_c image_wall_c.png 
 * Time-stamp: Sunday 11/03/2019, 06:34:51
 * 
 * Image Information
 * -----------------
 * image_wall_c.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_WALL_C_H
#define IMAGE_WALL_C_H

extern const unsigned short image_wall_c[64];
#define IMAGE_WALL_C_SIZE 128
#define IMAGE_WALL_C_LENGTH 64
#define IMAGE_WALL_C_WIDTH 8
#define IMAGE_WALL_C_HEIGHT 8

#endif

