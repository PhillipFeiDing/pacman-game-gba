/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_wall_0 image_wall_0.png 
 * Time-stamp: Sunday 11/03/2019, 06:33:15
 * 
 * Image Information
 * -----------------
 * image_wall_0.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_WALL_0_H
#define IMAGE_WALL_0_H

extern const unsigned short image_wall_0[64];
#define IMAGE_WALL_0_SIZE 128
#define IMAGE_WALL_0_LENGTH 64
#define IMAGE_WALL_0_WIDTH 8
#define IMAGE_WALL_0_HEIGHT 8

#endif

