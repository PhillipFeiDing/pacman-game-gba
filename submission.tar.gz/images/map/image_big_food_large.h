/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=14x14 image_big_food_large image_big_food_large.png 
 * Time-stamp: Saturday 11/16/2019, 05:42:42
 * 
 * Image Information
 * -----------------
 * image_big_food_large.png 14@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_BIG_FOOD_LARGE_H
#define IMAGE_BIG_FOOD_LARGE_H

extern const unsigned short image_big_food_large[196];
#define IMAGE_BIG_FOOD_LARGE_SIZE 392
#define IMAGE_BIG_FOOD_LARGE_LENGTH 196
#define IMAGE_BIG_FOOD_LARGE_WIDTH 14
#define IMAGE_BIG_FOOD_LARGE_HEIGHT 14

#endif

