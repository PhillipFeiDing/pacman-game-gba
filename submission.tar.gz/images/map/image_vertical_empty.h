/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=14x24 image_vertical_empty image_vertical_empty.png 
 * Time-stamp: Sunday 11/03/2019, 06:32:44
 * 
 * Image Information
 * -----------------
 * image_vertical_empty.png 14@24
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_VERTICAL_EMPTY_H
#define IMAGE_VERTICAL_EMPTY_H

extern const unsigned short image_vertical_empty[336];
#define IMAGE_VERTICAL_EMPTY_SIZE 672
#define IMAGE_VERTICAL_EMPTY_LENGTH 336
#define IMAGE_VERTICAL_EMPTY_WIDTH 14
#define IMAGE_VERTICAL_EMPTY_HEIGHT 24

#endif

