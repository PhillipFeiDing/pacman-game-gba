/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_food image_food.png 
 * Time-stamp: Sunday 11/03/2019, 06:29:13
 * 
 * Image Information
 * -----------------
 * image_food.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_FOOD_H
#define IMAGE_FOOD_H

extern const unsigned short image_food[64];
#define IMAGE_FOOD_SIZE 128
#define IMAGE_FOOD_LENGTH 64
#define IMAGE_FOOD_WIDTH 8
#define IMAGE_FOOD_HEIGHT 8

#endif

