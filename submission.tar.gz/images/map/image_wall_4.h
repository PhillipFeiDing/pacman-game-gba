/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_wall_4 image_wall_4.png 
 * Time-stamp: Sunday 11/03/2019, 06:33:34
 * 
 * Image Information
 * -----------------
 * image_wall_4.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_WALL_4_H
#define IMAGE_WALL_4_H

extern const unsigned short image_wall_4[64];
#define IMAGE_WALL_4_SIZE 128
#define IMAGE_WALL_4_LENGTH 64
#define IMAGE_WALL_4_WIDTH 8
#define IMAGE_WALL_4_HEIGHT 8

#endif

