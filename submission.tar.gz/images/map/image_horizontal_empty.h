/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=22x14 image_horizontal_empty image_horizontal_empty.png 
 * Time-stamp: Sunday 11/03/2019, 06:31:50
 * 
 * Image Information
 * -----------------
 * image_horizontal_empty.png 22@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_HORIZONTAL_EMPTY_H
#define IMAGE_HORIZONTAL_EMPTY_H

extern const unsigned short image_horizontal_empty[308];
#define IMAGE_HORIZONTAL_EMPTY_SIZE 616
#define IMAGE_HORIZONTAL_EMPTY_LENGTH 308
#define IMAGE_HORIZONTAL_EMPTY_WIDTH 22
#define IMAGE_HORIZONTAL_EMPTY_HEIGHT 14

#endif

