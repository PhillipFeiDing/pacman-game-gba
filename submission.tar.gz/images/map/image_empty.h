/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 image_empty image_empty.png 
 * Time-stamp: Monday 11/04/2019, 19:22:10
 * 
 * Image Information
 * -----------------
 * image_empty.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IMAGE_EMPTY_H
#define IMAGE_EMPTY_H

extern const unsigned short image_empty[64];
#define IMAGE_EMPTY_SIZE 128
#define IMAGE_EMPTY_LENGTH 64
#define IMAGE_EMPTY_WIDTH 8
#define IMAGE_EMPTY_HEIGHT 8

#endif

